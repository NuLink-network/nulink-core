"""
 This file is part of nucypher.

 nucypher is free software: you can redistribute it and/or modify
 it under the terms of the GNU Affero General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 nucypher is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU Affero General Public License for more details.

 You should have received a copy of the GNU Affero General Public License
 along with nucypher.  If not, see <https://www.gnu.org/licenses/>.
"""

#
# Contract Names
#

DISPATCHER_CONTRACT_NAME = 'Dispatcher'  # for Adjudicator contract , current useless
NULINK_TOKEN_CONTRACT_NAME = 'NuLinkToken'
STAKING_ESCROW_CONTRACT_NAME = 'StakingEscrow'  # current useless
ADJUDICATOR_CONTRACT_NAME = 'Adjudicator'  # current useless
# SimplePREApplication  =>  NodePoolStakingManager
PRE_APPLICATION_CONTRACT_NAME = 'SimplePREApplication'  # TODO: Use the real PREApplication
# SubscriptionManager  =>  PolicyManager
SUBSCRIPTION_MANAGER_CONTRACT_NAME = 'SubscriptionManager'
STAKING_POOL_CONTRACT_NAME = 'NuLinkStakingPool'
NODE_POOL_ROUTER_CONTRACT_NAME = 'NodePoolRouter'
NODE_POOL_FACTORY_CONTRACT_NAME = 'NodePoolFactory'
ERC721_NODE_POOL_NFT_CONTRACT_NAME = 'NodePoolNFT'

NULINK_CONTRACT_NAMES = (
    NULINK_TOKEN_CONTRACT_NAME,
    STAKING_ESCROW_CONTRACT_NAME,
    ADJUDICATOR_CONTRACT_NAME,
    DISPATCHER_CONTRACT_NAME,
    PRE_APPLICATION_CONTRACT_NAME,
    SUBSCRIPTION_MANAGER_CONTRACT_NAME,
    STAKING_POOL_CONTRACT_NAME,
    NODE_POOL_ROUTER_CONTRACT_NAME,
    NODE_POOL_FACTORY_CONTRACT_NAME
)


# Ethereum

AVERAGE_BLOCK_TIME_IN_SECONDS = 14
ETH_ADDRESS_BYTE_LENGTH = 20
ETH_ADDRESS_STR_LENGTH = 40
ETH_HASH_BYTE_LENGTH = 32
LENGTH_ECDSA_SIGNATURE_WITH_RECOVERY = 65
MAX_UINT16 = 65535
NULL_ADDRESS = '0x' + '0' * 40

# NuLink
# TODO: this is equal to HRAC.SIZE.
POLICY_ID_LENGTH = 16
